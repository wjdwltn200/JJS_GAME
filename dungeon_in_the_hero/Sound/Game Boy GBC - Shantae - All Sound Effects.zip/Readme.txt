Shantae (GBC)
Sound Effects ripped by Nai255

No credit needed, but feedback is welcome:
DoomedQuaker@hotmail.com

Includes unused sounds and variants for small hearts, medium gems, and big gems